
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.sc.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.Item;

import net.mcreator.sc.item.PicktestItem;
import net.mcreator.sc.ScMod;

public class ScModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, ScMod.MODID);
	public static final RegistryObject<Item> PICKTEST = REGISTRY.register("picktest", () -> new PicktestItem());
	// Start of user code block custom items
	// End of user code block custom items
}
